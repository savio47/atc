<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Dpost;
use DB;
use App\Dept;


class DpostsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     protected $dpost, $dept;
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
        $this->dpost = new Dpost();
        $this->dept = new Dept();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$dposts = Dpost::all();
        //return Dpost::where('title', 'Dpost Two')->get();
        //$dposts = DB::select('SELECT * FROM dposts');
        //$dposts = Dpost::orderBy('title','desc')->take(1)->get();
        //$dposts = Dpost::orderBy('title','desc')->get();

        $dposts = Dpost::orderBy('created_at','desc')->paginate(10);
        return view('dposts.index')->with('dposts', $dposts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dposts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // DB::beginTransaction();
        // try{
        $this->validate($request, [
            'flightno'=> 'required|regex:(^[A-Z]{1,3}[0-9]{1,4}+$)|unique:dposts|min:4|max:7', //https://regex101.com/r/FylFY1/2
            'flighttype'=> 'required',
            'tod'=> 'required',
            'dod'=> 'required',
            'runway'=> 'required',
            'route'=> 'required'
            
        ]);
            
        
        // Create Dpost
        $dpost = new Dpost;
        $dpost->flightno = $request->input('flightno');
        $dpost->flighttype = $request->input('flighttype');
        $dpost->tod = $request->input('tod');
        $dpost->dod = $request->input('dod');
        $dpost->runway = $request->input('runway');
        $dpost->route = $request->input('route');
        
        $dpost->user_id = auth()->user()->id;
        $dpost->save();

        $dept = new Dept;
        $dept->dflightno = $dpost->flightno;
        $dept->save();
        return redirect('/dposts')->with('success', 'Record Created');
        /* if($dpost && $dept){
            DB::commit();
        }else{
            DB::rollback();
            return redirect('/dposts')->with('success', 'Record Created');
        }
        
        return redirect('/dposts')->with('success', 'Record Created');
    }
    catch(Exception $ex){
        DB::rollback();
        return redirect('/dposts')->with('success', 'Record Created');
    } */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $dpost = Dpost::find($id);
        return view('dposts.show')->with('dpost', $dpost);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dpost = Dpost::find($id);

        // Check for correct user
        if(auth()->user()->id !==$dpost->user_id){
            return redirect('/dposts')->with('error', 'Unauthorized Page');
        }

        return view('dposts.edit')->with('dpost', $dpost);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'flightno'=> 'required',
            'flighttype'=> 'required',
            'tod'=> 'required',
            'dod'=> 'required',
            'runway'=> 'required',
            'route'=> 'required'
        ]);


        // Edit Dpost
        $dpost = Dpost::find($id);
        $dpost->flightno = $request->input('flightno');
        $dpost->flighttype = $request->input('flighttype');
        $dpost->tod = $request->input('tod');
        $dpost->dod = $request->input('dod');
        $dpost->runway = $request->input('runway');
        $dpost->route = $request->input('route');
       
        $dpost->save();

        return redirect('/dposts')->with('success', 'Record Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dpost = Dpost::find($id);

        // Check for correct user
        if(auth()->user()->id !==$dpost->user_id){
            return redirect('/dposts')->with('error', 'Unauthorized Page');
        }

      
        
        $dpost->delete();
        return redirect('/dposts')->with('success', 'Record Removed');
    }
}
