<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Arrival;
use DB;

class ArrivalsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function index()
    {
        $arrivals = Arrival::all();
        

        $arrival = Arrival::orderBy('created_at','desc')->paginate(10);
        return view('arrivals.index')->with('arrivals', $arrivals);
    
    } 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //return view('posts.create');
        return view('arrivals.create');
        /* foreach ($posts as $post){
            $arrival = new Arrival();
            $arrival->flightno = $post->flightno;
            $arrival->save();
        } */
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'flightno'=> 'required',
            /* 'Security_Code'=> 'required|regex:(abcd)',
            'cleaning'=> 'required',
            'rampservice'=> 'required',
            'waste'=> 'required',
            'deicing'=> 'required', */
        ]);

        /* foreach ($posts as $post){
            $arrival = new Arrival();
            $arrival->flightno = $post->flightno;
            $arrival->save();
        } */
        // Create arrival
        $arrival = new Arrival;
        $arrival->aflightno = $request->input('aflightno');
       //$arrival->post_flightno = $request-> $post->flightno;
        $arrival->Security_Code = $request->input('Security_Code');
        $arrival->cleaning = $request->input('cleaning');
        $arrival->rampservice = $request->input('rampservice');
        $arrival->waste = $request->input('waste');
        $arrival->deicing = $request->input('deicing'); 
        
        
        $arrival->save();

        return redirect('/arrivals')->with('success', 'Record Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $arrival = Arrival::find($id);
        return view('arrivals.show')->with('arrival', $arrival);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $arrival = Arrival::find($id);
        return view('arrivals.edit')->with('arrival', $arrival);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            //'aflightno'=> 'required',
            'Security_Code'=> 'required|regex:(abcd)',
            'cleaning'=> 'required',
            'rampservice'=> 'required',
            'waste'=> 'required',
            'deicing'=> 'required',
        ]);


        // Edit Arrival
        $arrival = Arrival::find($id);
        //$arrival->aflightno = $request->input('aflightno');
        $arrival->Security_Code = $request->input('Security_Code');
        $arrival->cleaning = $request->input('cleaning');
        $arrival->rampservice = $request->input('rampservice');
        $arrival->waste = $request->input('waste');
        $arrival->deicing = $request->input('deicing');
        $arrival->save();
        return redirect('/arrivals')->with('success', 'Record Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $arrival = Arrival::find($id);     
        
        $arrival->delete();
        return redirect('/arrivals')->with('success', 'Record Removed');
    }
}
