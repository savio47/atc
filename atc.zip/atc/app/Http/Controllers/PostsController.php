<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Post;
use DB;
use App\Arrival;
//use App\Http\Controllers\ArrivalsController;

class PostsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     protected $post, $arrival;
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
        $this->post = new Post();
        $this->arrival = new Arrival();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$posts = Post::all();
        //return Post::where('title', 'Post Two')->get();
        //$posts = DB::select('SELECT * FROM posts');
        //$posts = Post::orderBy('title','desc')->take(1)->get();
        //$posts = Post::orderBy('title','desc')->get();

        $posts = Post::orderBy('created_at','desc')->paginate(10);
        return view('posts.index')->with('posts', $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // DB::beginTransaction();
        // try{
        $this->validate($request, [
            'flightno'=> 'required|regex:(^[A-Z]{1,3}[0-9]{1,4}+$)|unique:posts|min:4|max:7',       //https://regex101.com/r/FylFY1/2
            'flighttype'=> 'required',
            'toa'=> 'required',
            'doa'=> 'required',
            'runway'=> 'required',
            'route'=> 'required',
            'parking'=> 'required'
        ]);
            
        
        // Create Post
        $post = new Post;
        $post->flightno = $request->input('flightno');
        $post->flighttype = $request->input('flighttype');
        $post->toa = $request->input('toa');
        $post->doa = $request->input('doa');
        $post->runway = $request->input('runway');
        $post->route = $request->input('route');
        $post->parking = $request->input('parking');
        $post->user_id = auth()->user()->id;
        $post->save();

        $arrival = new Arrival;
        $arrival->aflightno = $post->flightno;
        $arrival->save();
        return redirect('/posts')->with('success', 'Record Created');
        /* if($post && $arrival){
            DB::commit();
        }else{
            DB::rollback();
            return redirect('/posts')->with('success', 'Record Created');
        }
        
        return redirect('/posts')->with('success', 'Record Created');
    }
    catch(Exception $ex){
        DB::rollback();
        return redirect('/posts')->with('success', 'Record Created');
    } */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $post = Post::find($id);
        return view('posts.show')->with('post', $post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::find($id);

        // Check for correct user
        if(auth()->user()->id !==$post->user_id){
            return redirect('/posts')->with('error', 'Unauthorized Page');
        }

        return view('posts.edit')->with('post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'flightno'=> 'required',
            'flighttype'=> 'required',
            'toa'=> 'required',
            'doa'=> 'required',
            'runway'=> 'required',
            'route'=> 'required',
            'parking'=> 'required'
        ]);


        // Edit Post
        $post = Post::find($id);
        $post->flightno = $request->input('flightno');
        $post->flighttype = $request->input('flighttype');
        $post->toa = $request->input('toa');
        $post->doa = $request->input('doa');
        $post->runway = $request->input('runway');
        $post->route = $request->input('route');
        $post->parking = $request->input('parking');
        
        $post->save();

        return redirect('/posts')->with('success', 'Record Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);

        // Check for correct user
        if(auth()->user()->id !==$post->user_id){
            return redirect('/posts')->with('error', 'Unauthorized Page');
        }

      
        
        $post->delete();
        return redirect('/posts')->with('success', 'Record Removed');
    }
}
