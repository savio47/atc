@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<body>
{{-- <a href="/depts/create" class="btn btn-primary btn-lg btn-block">Create Aircraft Clearance Record</a>
    <br><br> --}}
    <h1> Aircraft Before Departure Requests</h1>
    <br>   
    @if(count($depts) > 0)        
            {{-- <div class="well">
                <div class="row">                   
                    <div class="col-md-4 col-sm-4">
                        <h3>{{$dept->flightno_a}}</h3>
                        <h4>Cleaning : {!!$dept->cleaning!!}</h4>
                        <h4>Ramp Service : {!!$dept->rampservice!!}</h4> 
                        <h4>Waste Collection Truck : {!!$dept->waste!!}</h4>   
                        <h4>Deicing : {!!$dept->deicing!!}</h4> 
                    </div>
                </div>
            </div> --}}
            <table class="table table-striped table-bordered table-sm">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Plane Outer inspection </h3></th> 
                    <th><h3 style="color:purple;">Supplies and Inventory Check</h3></th>
                    <th><h3>Catering Service</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                @foreach($depts as $dept)
                @if($dept->cleaning == null)
                {{-- @if(empty($dept->cleaning)  --}}
                <tr>
                        
                            <td><h3 style="color:red;">{{$dept->dflightno}} </h3></td> 
                            {{-- <td><h3><a href="/dposts/{{$dpost->id}}">{{$dept->dflightno}}</a></h3></td> --}}
                            <td colspan="4"><h3 style="color:green;"><a href="depts/{{$dept->id}}/edit" class="btn btn-primary btn-lg btn-block">Create</a></h3></td>
                            
                            </tr>
                           
                @endif
                @if($dept->cleaning != null)
                    <tr>
                        <td><h3 style="color:red;">{{$dept->dflightno}} </h3></td>
                        <td><h3 style="color:green;">{!!$dept->cleaning!!}</h3></td>
                        <td><h3 style="color:purple;">{!!$dept->rampservice!!}</h3></td>
                        <td><h3>{!!$dept->waste!!}</h3></td>
                        <td><h3 style="color:blue;">{!!$dept->deicing!!}</h3></td>
                        
                    </tr>
                    @endif
                {{-- @endforeach --}}
                @endforeach
            </table>
        
        
    @else
        <p>No Records Found</p>
    @endif
  </body>
  </html>
@endsection