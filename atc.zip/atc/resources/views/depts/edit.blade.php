@extends('layouts.app')

@section('content')
<a href="/depts/" class="btn btn-default">Go Back</a>
    <h1>Before Departure Requests</h1>
    {!! Form::open(['action' => ['DeptsController@update', $dept->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        
        <h3 style="color:red;">Flight number: {{$dept->dflightno}} </h3>
        {{-- <div class="form-group">
            {{Form::label('cleaning', 'Cleaning :')}}
            {{Form::checkbox('cleaning', $dept->cleaning, ['class' => 'form-control'])}}
        </div>
        
        <div class="form-group">
            {{Form::label('rampservice', 'Ramp Service :')}}
            {{Form::checkbox('rampservice', $dept->rampservice, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('waste', 'Waste Collection Truck :')}}
            {{Form::checkbox('waste', $dept->waste, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('deicing', 'Deicing :')}}
            {{Form::checkbox('deicing', $dept->deicing, ['class' => 'form-control'])}}
        </div> --}}
        <div class="form-group">
            {{Form::label('Security_Code', 'Security Code of Flight :')}}
            {{Form::text('Security_Code', '', ['class' => 'form-control', 'placeholder' => 'Enter Secutity Code / OTP of flight'])}}
        </div> 
        <div class="form-group">
            {{Form::label('cleaning', 'Plane Outer inspection : ')}}
            {{Form::select('cleaning', ['Yes' => 'Yes', 'No' => 'No'], $dept->cleaning,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('rampservice', 'Supplies and Inventory Check : ')}}
            {{Form::select('rampservice', ['Yes' => 'Yes', 'No' => 'No'], $dept->rampservice,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('waste', 'Catering Service : ')}}
            {{Form::select('waste', ['Yes' => 'Yes', 'No' => 'No'], $dept->waste,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('deicing', 'Deicing : ')}}
            {{Form::select('deicing', ['Yes' => 'Yes', 'No' => 'No'], $dept->deicing,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div>  
        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        <br><br>
    {!! Form::close() !!}
@endsection