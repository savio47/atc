@extends('layouts.app')

@section('content')
    <a href="/depts" class="btn btn-default">Go Back</a>
    <br>
    <h1>{{$dept->dflightno}}</h1>
    <br>
    <div class="well">
        {{-- <small>Entered on {{$dept->created_at}}</small> --}}
        <h2>Flight No. : {!!$dept->flightno!!} </a></h2>
        <h4>Cleaning : {!!$dept->cleaning!!}</h4>
        <h4>Ramp Service : {!!$dept->rampservice!!}</h4> 
        <h4>Waste Collection Truck : {!!$dept->waste!!}</h4>   
        <h4>Deicing : {!!$dept->deicing!!}</h4>
        <br>
</div>
    <hr>
    <small>Entered on {{$dept->created_at}} by {{$dept->user->name}} (ATCT)</small>
    <hr>
    @if(!Auth::guest())
        @if(Auth::user()->id == $dept->user_id)
           <a href="/depts/{{$dept->id}}/edit" class="btn btn-success">Edit</a> 

            {!!Form::open(['action' => ['ArrivalsController@destroy', $dept->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
@endsection