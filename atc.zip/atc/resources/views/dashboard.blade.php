@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">ACTC Dashboard</div>

                <div class="panel-body">
                    <a href="/posts" class="btn btn-primary btn-lg btn-block">View Aircraft Arrival Clearance Record</a>
                    <br><br>
                    <a href="/dposts" class="btn btn-success btn-lg btn-block">View Aircraft Departure Clearance Records</a>
                
                    {{-- <h3>Your Aircraft Clearance Records</h3>
                    @if(count($posts) > 0)
                        <table class="table table-striped">
                            <tr>
                                <th>Title</th>
                                {{-- <th></th> 
                                <th></th>
                            </tr>
                            @foreach($posts as $post)
                                <tr>
                                     <td>{{$post->flightno}}</td> 
                                    <td><h3><a href="/posts/{{$post->id}}">{{$post->flightno}}</a></h3></td>
                                    <td><a href="/posts/{{$post->id}}/edit" class="btn btn-default">Edit</a></td>
                                    <td>
                                        {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                                            {{Form::hidden('_method', 'DELETE')}}
                                            {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
                                        {!!Form::close()!!}
                                    </td>
                                </tr>
                            @endforeach
                        </table>
                    @else
                        <p>You have no Aircraft Clearance Records</p>
                        
                    @endif --}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
