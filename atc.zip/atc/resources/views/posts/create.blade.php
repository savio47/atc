@extends('layouts.app')

@section('content')
{{-- <a href="/posts/{{$post->id}}" class="btn btn-default">Go Back</a> --}}
    <h1>Create Aircraft Arrival Clearance Record</h1>
    {!! Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('flightno', 'Flight No.')}}
            {{Form::text('flightno', '', ['class' => 'form-control', 'placeholder' => 'Flight no. format (eg:KL722)'])}}
        </div>      
        {{-- <div class="form-group">
            {{Form::label('flighttype', 'Flight Type :')}}
            {{Form::select('flighttype', [
            'Passenger' => ['Small Aircraft' => 'Small Aircraft', 'Propeller Aircraft' => 'Propeller Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter'],
            'Cargo' => ['cargo' => 'Cargo'], 
            ])}}
        </div> --}}
        
        <div class="form-group">
            {{Form::label('flighttype', 'Flight Type :')}}
            {{Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], null,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])}}
        </div> 
        <div class="form-group">
            {{Form::label('toa', 'Time of Arrival : (Hours(24) : Minutes : Seconds)')}}
            {{-- {{Form::time('time', \Carbon\Carbon::now()->timezone('	Asia/Calcutta')->format('H:i:s'),['class' => 'form-control'])} --}}
            {{Form::time('toa', Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('H:i:s'),['class' => 'form-control', 'placeholder' =>'Arrival Time'])}}
        </div>
        <div class="form-group">
            {{Form::label('doa', 'Date of Arrival : (Date - Month - Year)')}}
            {{Form::date('doa', \Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('d-m-Y'),['class' => 'form-control', 'placeholder' =>'Arrival Date'])}}
        </div>
        <div class="form-group">
            {{Form::label('runway', 'Runway ( 12 L/R ) ')}}
            {{Form::select('runway', ['12R' => '12R','12L' => '12L'], null,['class' => 'form-control', 'placeholder' =>'Select Runway and direction'])}}
        </div> 
        <div class="form-group">
            {{Form::label('route', 'Route ')}}
            {{Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], null,['class' => 'form-control', 'placeholder' =>'Select the Route to travel'])}}
        </div>
        <div class="form-group">
            {{Form::label('parking', 'Parking Space: ')}}
            {{Form::select('parking', ['P1' => 'P1', 'P2' => 'P2', 'P3' => 'P3','P4' => 'P4', 'P5' => 'P5'], null,['class' => 'form-control', 'placeholder' =>'Select the Parking Space'])}}
        </div> 
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!} 
@endsection