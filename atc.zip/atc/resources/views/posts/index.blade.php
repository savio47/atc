@extends('layouts.app')

@section('content')
{{-- <a href="/dashboard">Dashboard</a> --}}
<a href="/posts/create" class="btn btn-primary btn-lg btn-block">Create Aircraft Clearance Record</a>
    <br><br>
    <h1> Aircraft Arrival Clearance Records</h1>
    @if(count($posts) > 0)
        @foreach($posts as $post)
            <div class="well">
                <div class="row">                   
                    <div class="col-md-4 col-sm-4">
                            {{-- Record No : {{$post->id}} --}}
                        <h3> {{-- {{$post->id}}.  --}} <a href="/posts/{{$post->id}}">{{$post->flightno}}</a></h3>
                        <small>Entered on {{$post->created_at}} by {{$post->user->name}} (ATCT)</small>
                    </div>
                </div>
            </div>
        @endforeach
        {{$posts->links()}}
    @else
        <p>No Aircraft Clearance Records Found</p>
    @endif
@endsection