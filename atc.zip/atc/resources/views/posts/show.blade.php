@extends('layouts.app')

@section('content')
    <a href="/posts" class="btn btn-default">Go Back</a>
    <br>
    <h1>{{$post->flightno}}</h1>
    <br>
    <div class="well">
        {{-- <small>Entered on {{$post->created_at}}</small> --}}
        <h2>Flight No. : {!!$post->flightno!!} </a></h2>
        <h4>Flight Type : {!!$post->flighttype!!}</h4>
        <h4>Time of Arrival : {!!$post->toa!!}</h4> 
        <h4>Date of Arrival : {!!$post->doa!!}</h4>   
        <h4>Runway : {!!$post->runway!!}</h4>
        <h4>Route : {!!$post->route!!}</h4>
        <h4>Parking Space: {!!$post->parking!!}</h4>
    <br>
</div>
    <hr>
    <small>Entered on {{$post->created_at}} by {{$post->user->name}} (ATCT)</small>
    <hr>
    @if(!Auth::guest())
        @if(Auth::user()->id == $post->user_id)
           <a href="/posts/{{$post->id}}/edit" class="btn btn-success">Edit</a> 

            {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
@endsection