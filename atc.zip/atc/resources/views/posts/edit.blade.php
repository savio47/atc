@extends('layouts.app')

@section('content')
<a href="/posts/{{$post->id}}" class="btn btn-default">Go Back</a>
    <h1>Edit Aircraft Arrival Clearance Record</h1>
    {!! Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('flightno', 'Flight No.')}}
            {{Form::text('flightno', $post->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no', /* 'disabled' */])}}
        </div>
        {{-- <div class="form-group">
            {{Form::label('flighttype', 'Flight type ')}}
            {{Form::select('flighttype', [
                'Passenger' => ['Small Aircraft' => 'Small Aircraft', 'Propeller Aircraft' => 'Propeller Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter'],
                'Cargo' => ['cargo' => 'Cargo'], $post->flighttype, ['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])}}
        </div> --}}
        <div class="form-group">
            {{Form::label('flighttype', 'Flight Type :')}}
            {{Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], $post->flighttype,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])}}
        </div>
        <div class="form-group">
            {{Form::label('toa', 'Time of Arrival : (Hours : Minutes : Seconds)')}}
            {{Form::time('toa', $post->toa,['class' => 'form-control'])}} 
        </div> 
        <div class="form-group">
            {{Form::label('doa', 'Date of Arrival : (Date - Month - Year)')}}
            {{Form::date('doa', $post->doa,['class' => 'form-control'])}} 
        </div>
        <div class="form-group">
            {{Form::label('runway', 'Runway :')}}
            {{Form::select('runway', ['12L' => '12L', '12R' => '12R'], $post->runway,['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('route', 'Route ')}}
            {{Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], $post->route,['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('parking', 'Parking Space: ')}}
            {{Form::select('parking', ['P1' => 'P1', 'P2' => 'P2', 'P3' => 'P3','P4' => 'P4', 'P5' => 'P5'], $post->parking,['class' => 'form-control'])}}
        </div> 

        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        <br><br>
    {!! Form::close() !!}
@endsection