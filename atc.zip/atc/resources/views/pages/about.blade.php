@extends('layouts.app')

@section('content')
    <h1><?php echo $title; ?></h1>
    <p>This is the about page</p>

    <br><br>
    <h1> Aircraft On Arrival Requests</h1>
    <br>
    @if(count($arrivals) > 0)
            <table class="table table-striped">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Cleaning </h3></th> 
                    <th><h3 style="color:purple;">Ramp Service</h3></th>
                    <th><h3>Waste Collection Truck</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                @foreach($arrivals as $arrival)
                    <tr>
                        <td><h3 style="color:red;">{{$arrival->post_flightno}}</h3></td>
                        <td><h3 style="color:green;">{!!$arrival->cleaning!!}</h3></td>
                        <td><h3 style="color:purple;">{!!$arrival->rampservice!!}</h3></td>
                        <td><h3>{!!$arrival->waste!!}</h3></td>
                        <td><h3 style="color:blue;">{!!$arrival->deicing!!}</h3></td>
                        <td></td>
                    </tr>
                @endforeach
            </table>
        
        
    @else
        <p>No Records Found</p>
    @endif
@endsection