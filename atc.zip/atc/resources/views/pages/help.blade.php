@extends('layouts.app')
@section('content')
<h2 style="color:brown;">Frequently Asked Questions (FAQ'S) and Reference Map</h2><br>
{{-- <img src="storage\_images\map1.png" class="img-fluid" alt="Responsive image" width="90%" height="500">  --}}
<br>
<p style="color:black;"><br><strong>To Create Aircraft Clearance Record, </strong>  
        the following details must be entered:
        <br>1)	<strong>Flight Number :</strong> A flight number or flight designator is a code for an airline service consisting of 1 to 3 character airline designator and a 1 to 4 digit number. Egs: BA2490 ; A334 ; KLM4485.
        <br>2)	<strong>Flight Type :</strong> Select from list. Refer document
        <br>3)	<strong>Time of Arrival :</strong> (Hours(24) : Minutes : Seconds) Format
        <br>4)	<strong>Date of Arrival :</strong> (Date - Month - Year) Format
        <br>5)	<strong>Runway ( 12/30 ; L/R ) :</strong> Select which runway and direction to land
        <br>6)	<strong>Route :</strong> Select route pathway from source(runway) to destination(parking), from A-D. Refer Map
        <br>Route A for 30R:1-2
        <br>Route B for 30L:38-36-1-2
        <br>Route C for 12L:19-16-14-10-8-4-2
        <br>Route D for 12R:21-25-27-33-35-36-1-2
        <br>7)	<strong>Parking Space :</strong> Select from P1-P5. Refer Map
</p>
        <br>
@endsection