@extends('layouts.app')

@section('content')
<body>
    <div class="jumbotron text-center">
        <img src="storage\_images\ATC_tower.jpg" class="img-fluid" alt="Responsive image" width="80%" height="240"> 
        <div class="container">
        <h1 style="color:blue;">Welcome To Ground Aircraft Handling and Support System</h1>
        {{-- <p style="color:blue;">Ground Aircraft Handling and Support System defines the service provided to the aircraft while it is on the ground. This system helps the pilot to park the aircraft at a correct position without any accidents and ask for any support from the airport authorities.</p> --}}
        {{-- <br>
        <br> --}}
    </div>
    </div>
</body>

    {{-- <footer class="mastfoot mt-auto">
        <div class="inner">
            <p>Copywrited &copy; 2018-19 Company, Inc.</p>
        </div>
    </footer> --}}
@endsection
