@extends('layouts.app')

@section('content')
    <a href="/arrivals" class="btn btn-default">Go Back</a>
    <br>
    <h1>{{$arrival->flightno_a}}</h1>
    <br>
    <div class="well">
        {{-- <small>Entered on {{$arrival->created_at}}</small> --}}
        <h2>Flight No. : {!!$arrival->flightno!!} </a></h2>
        <h4>Cleaning : {!!$arrival->cleaning!!}</h4>
        <h4>Ramp Service : {!!$arrival->rampservice!!}</h4> 
        <h4>Waste Collection Truck : {!!$arrival->waste!!}</h4>   
        <h4>Deicing : {!!$arrival->deicing!!}</h4>
        <br>
</div>
    <hr>
    <small>Entered on {{$arrival->created_at}} by {{$arrival->user->name}} (ATCT)</small>
    <hr>
    @if(!Auth::guest())
        @if(Auth::user()->id == $arrival->user_id)
           <a href="/arrivals/{{$arrival->id}}/edit" class="btn btn-success">Edit</a> 

            {!!Form::open(['action' => ['ArrivalsController@destroy', $arrival->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
@endsection