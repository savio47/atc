@extends('layouts.app')

@section('content')
    <h1>Create Aircraft On Arrival Requests</h1>
    {!! Form::open(['action' => 'ArrivalsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
     {{--  <div class="form-group">
        {{Form::label('posts_flightno', 'Flight No.')}}
        {{Form::text('posts_flightno', '', ['class' => 'form-control'])}}
     </div>  --}}  
     {{-- <div class="form-group">
        {{Form::label('flightno', 'Flight No.')}}
        {{Form::text('flightno', $post->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no'])}}
    </div> --}}
    <div class="form-group">
        {{Form::label('security_code', 'Security Code of Flight')}}
        {{Form::password('security_code', '', ['class' => 'form-control', 'placeholder' => 'Enter Secutity Code / OTP of flight'])}}
    </div> 
        <div class="form-group">
            {{Form::label('cleaning', 'Cleaning : ')}}
            {{Form::select('cleaning', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('rampservice', 'Ramp Service : ')}}
            {{Form::select('rampservice', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('waste', 'Waste Collection Truck : ')}}
            {{Form::select('waste', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('deicing', 'Deicing : ')}}
            {{Form::select('deicing', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control'])}}
        </div>  


        {{-- <div class="form-group">
            {{Form::label('cleaning', 'Cleaning :')}}
            {{Form::checkbox('cleaning', 'cleaning', true, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('rampservice', 'Ramp Service :')}}
            {{Form::checkbox('rampservice', 'rampservice', true, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('waste', 'Waste Collection Truck :')}}
            {{Form::checkbox('waste', 'waste', true, ['class' => 'form-control'])}}
        </div>

        <div class="form-group">
            {{Form::label('deicing', 'Deicing :')}}
            {{Form::checkbox('deicing', 'deicing', false, ['class' => 'form-control'])}}
        </div> --}}

        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        {{-- <br><br> --}}
    {!! Form::close() !!}
@endsection