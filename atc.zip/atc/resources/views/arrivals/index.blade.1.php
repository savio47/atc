@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<body>
{{-- <a href="/arrivals/create" class="btn btn-primary btn-lg btn-block">Create Aircraft Clearance Record</a>
    <br><br> --}}
    <h1> Aircraft On Arrival Requests</h1>
    <br>   
    @if(count($arrivals) > 0)        
            {{-- <div class="well">
                <div class="row">                   
                    <div class="col-md-4 col-sm-4">
                        <h3>{{$arrival->flightno_a}}</h3>
                        <h4>Cleaning : {!!$arrival->cleaning!!}</h4>
                        <h4>Ramp Service : {!!$arrival->rampservice!!}</h4> 
                        <h4>Waste Collection Truck : {!!$arrival->waste!!}</h4>   
                        <h4>Deicing : {!!$arrival->deicing!!}</h4> 
                    </div>
                </div>
            </div> --}}
            <table class="table table-striped table-bordered table-sm">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Cleaning </h3></th> 
                    <th><h3 style="color:purple;">Ramp Service</h3></th>
                    <th><h3>Waste Collection Truck</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                @foreach($arrivals as $arrival)
                @if($arrival->cleaning == null)
                {{-- @if(empty($arrival->cleaning)  --}}
                <tr>
                        
                            <td><h3 style="color:red;">{{$arrival->aflightno}} </h3></td> 
                            {{-- <td><h3><a href="/posts/{{$post->id}}">{{$arrival->aflightno}}</a></h3></td> --}}
                            {{-- <td colspan="4"><h3 style="color:green;"><a href="arrivals/{{$arrival->id}}/edit" class="btn btn-primary btn-lg btn-block">Create</a></h3></td> --}}
                            <td colspan="4">
                            
                            <button type="button" class="btn btn-primary btn-lg btn-block" data-toggle="modal" data-target="#exampleModal" data-whatever="">Create Request</button>
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h3 class="modal-title" id="exampleModalLabel">Creating On Arrival Request</h3>
                                    {{-- <a style="color:red;">{{$arrival->aflightno}}</a> --}}
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                      <form action="script.cgi" onSubmit="return checkform()">
                                      <div class="form-group">
                                        <label for="otp" class="col-form-label"> Enter OTP :</label>
                                        <input type="password" class="form-control" id="otp" name="otp" value="" pattern="[A-Za-z]{3}" required>
                                        {{-- <div class="invalid-feedback">
                                          Incorrect OTP!
                                        </div> --}}
                                      </div>
                                    
                                    </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <a href="arrivals/{{$arrival->id}}/edit"><button type="submit" class="btn btn-primary">Submit</button></a>
                                    {{-- <input type="text" id="example" name="example" pattern="[A-Za-z]{3}" value="abc" required> --}}
                                   {{--  <button type="button"  onclick="submitform()" id="save">Save</button>
                                    <input id="submit_handle" type="submit" style="display: none">
                                    <script>
                                      function submitform() {
                                        $('#submit_handle').click();
                                          }
                                    </script> --}}
                                    <script>
                                    function checkform()
                                    {
	                                  if ('otp' != 'abc' )
	                                  {
		                                  // something is wrong
		                                  alert('Incorrect OTP!');
		                                  return false;
	                                  }
	                                    // If the script gets this far through all of your fields
	                                    // without problems, it's ok and you can submit the form
	                                  return true;
                                    }
                                    </script>
                                  </div>
                                </div>
                              </div>
                            </div>  
                        </td>
    
                </tr>
                @endif
                @if($arrival->cleaning != null)
                    <tr>
                        <td><h3 style="color:red;">{{$arrival->aflightno}} </h3></td>
                        <td><h3 style="color:green;">{!!$arrival->cleaning!!}</h3></td>
                        <td><h3 style="color:purple;">{!!$arrival->rampservice!!}</h3></td>
                        <td><h3>{!!$arrival->waste!!}</h3></td>
                        <td><h3 style="color:blue;">{!!$arrival->deicing!!}</h3></td>
                        
                    </tr>
                    @endif
                
                @endforeach
            </table>
        
        
    @else
        <p>No Records Found</p>
    @endif
  </body>
  </html>
@endsection