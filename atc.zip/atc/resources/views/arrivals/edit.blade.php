@extends('layouts.app')

@section('content')
<a href="/arrivals/" class="btn btn-default">Go Back</a>
    <h1>On Arrival Requests</h1>
    {!! Form::open(['action' => ['ArrivalsController@update', $arrival->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        {{-- <div class="form-group">
            {{Form::label('flightno', 'Flight No.')}}
            {{Form::text('flightno', $arrival->aflightno, ['class' => 'form-control', 'placeholder' => 'Flight no'])}}
        </div> --}}
        <h3 style="color:red;">Flight number: {{$arrival->aflightno}} </h3>
        {{-- <div class="form-group">
            {{Form::label('cleaning', 'Cleaning :')}}
            {{Form::checkbox('cleaning', $arrival->cleaning, ['class' => 'form-control'])}}
        </div>
        
        <div class="form-group">
            {{Form::label('rampservice', 'Ramp Service :')}}
            {{Form::checkbox('rampservice', $arrival->rampservice, ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('waste', 'Waste Collection Truck :')}}
            {{Form::checkbox('waste', $arrival->waste, ['class' => 'form-control'])}}
        </div>

        <div class="form-group">
            {{Form::label('deicing', 'Deicing :')}}
            {{Form::checkbox('deicing', $arrival->deicing, ['class' => 'form-control'])}}
        </div> --}}
        <div class="form-group">
            {{Form::label('Security_Code', 'Security Code of Flight :')}}
            {{Form::text('Security_Code', '', ['class' => 'form-control', 'placeholder' => 'Enter Secutity Code / OTP of flight'])}}
        </div> 
        <div class="form-group">
            {{Form::label('cleaning', 'Cleaning : ')}}
            {{Form::select('cleaning', ['Yes' => 'Yes', 'No' => 'No'], $arrival->cleaning,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('rampservice', 'Ramp Service : ')}}
            {{Form::select('rampservice', ['Yes' => 'Yes', 'No' => 'No'], $arrival->rampservice,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('waste', 'Waste Collection Truck : ')}}
            {{Form::select('waste', ['Yes' => 'Yes', 'No' => 'No'], $arrival->waste,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div> 
        <div class="form-group">
            {{Form::label('deicing', 'Deicing : ')}}
            {{Form::select('deicing', ['Yes' => 'Yes', 'No' => 'No'], $arrival->deicing,['class' => 'form-control', 'placeholder' =>'Select the option'])}}
        </div>  
        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        <br><br>
    {!! Form::close() !!}
@endsection