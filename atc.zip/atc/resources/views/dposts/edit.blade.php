@extends('layouts.app')

@section('content')
<a href="/dposts/{{$dpost->id}}" class="btn btn-default">Go Back</a>
    <h1>Edit Aircraft Departure Clearance Record</h1>
    {!! Form::open(['action' => ['DpostsController@update', $dpost->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('flightno', 'Flight No.')}}
            {{Form::text('flightno', $dpost->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no', /* 'disabled' */])}}
        </div>
        <div class="form-group">
            {{Form::label('flighttype', 'Flight Type :')}}
            {{Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], $dpost->flighttype,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])}}
        </div>
        <div class="form-group">
            {{Form::label('tod', 'Time of Departure : (Hours : Minutes : Seconds)')}}
            {{Form::time('tod', $dpost->tod,['class' => 'form-control'])}} 
        </div> 
        <div class="form-group">
            {{Form::label('dod', 'Date of Departure : (Date - Month - Year)')}}
            {{Form::date('dod', $dpost->dod,['class' => 'form-control'])}} 
        </div>
        <div class="form-group">
            {{Form::label('runway', 'Runway :')}}
            {{Form::select('runway', ['12L' => '12L', '12R' => '12R'], $dpost->runway,['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('route', 'Route ')}}
            {{Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], $dpost->route,['class' => 'form-control'])}}
        </div>
        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        <br><br>
    {!! Form::close() !!}
@endsection