@extends('layouts.app')

@section('content')
    <a href="/dposts" class="btn btn-default">Go Back</a>
    <br>
    <h1>{{$dpost->flightno}}</h1>
    <br>
    <div class="well">
        {{-- <small>Entered on {{$post->created_at}}</small> --}}
        <h2>Flight No. : {!!$dpost->flightno!!} </a></h2>
        <h4>Flight Type : {!!$dpost->flighttype!!}</h4>
        <h4>Time of Departure : {!!$dpost->tod!!}</h4> 
        <h4>Date of Departure : {!!$dpost->dod!!}</h4>   
        <h4>Runway : {!!$dpost->runway!!}</h4>
        <h4>Route : {!!$dpost->route!!}</h4>
        
    <br>
</div>
    <hr>
    <small>Entered on {{$dpost->created_at}} by {{$dpost->user->name}} (ATCT)</small>
    <hr>
    @if(!Auth::guest())
        @if(Auth::user()->id == $dpost->user_id)
           <a href="/dposts/{{$dpost->id}}/edit" class="btn btn-success">Edit</a> 

            {!!Form::open(['action' => ['PostsController@destroy', $dpost->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
                {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
            {!!Form::close()!!}
        @endif
    @endif
@endsection