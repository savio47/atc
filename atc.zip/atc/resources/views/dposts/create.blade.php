@extends('layouts.app')

@section('content')
    <h1>Create Aircraft Departure Clearance Record</h1>
    {!! Form::open(['action' => 'DpostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
    {{-- {!! Form::open(['action' => 'ArrivalsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}  --}}
        <div class="form-group">
            {{Form::label('flightno', 'Flight No.')}}
            {{Form::text('flightno', '', ['class' => 'form-control', 'placeholder' => 'Flight no (eg:KL722)'])}}
        </div>
        
        <div class="form-group">
            {{Form::label('flighttype', 'Flight Type :')}}
            {{Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], null,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])}}
        </div> 
        <div class="form-group">
            {{Form::label('tod', 'Time of Departure : (Hours(24) : Minutes : Seconds)')}}
            {{Form::time('tod', Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('H:i:s'),['class' => 'form-control', 'placeholder' =>'Departure Time'])}}
        </div>
        <div class="form-group">
            {{Form::label('dod', 'Date of Departure : (Date - Month - Year)')}}
            {{Form::date('dod', \Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('d-m-Y'),['class' => 'form-control', 'placeholder' =>'Departure Date'])}}
        </div>
        <div class="form-group">
            {{Form::label('runway', 'Runway ( 12 L/R ) ')}}
            {{Form::select('runway', ['12L' => '12L', '12R' => '12R'], null,['class' => 'form-control', 'placeholder' =>'Select Runway and direction'])}}
        </div> 
        <div class="form-group">
            {{Form::label('route', 'Route ')}}
            {{Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], null,['class' => 'form-control', 'placeholder' =>'Select the Route to travel'])}}
        </div>
        {{-- <div class="form-group">
            {{Form::label('parking', 'Parking Space: ')}}
            {{Form::select('parking', ['P1' => 'P1', 'P2' => 'P2', 'P3' => 'P3','P4' => 'P4', 'P5' => 'P5'], null,['class' => 'form-control', 'placeholder' =>'Select the Parking Space'])}}
        </div>  --}}
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
        
    {!! Form::close() !!} 
@endsection