@extends('layouts.app')

@section('content')

<a href="/dposts/create" class="btn btn-primary btn-lg btn-block">Create Aircraft Departure Clearance Record</a>
    <br><br>
    <h1 style="color:purple;"> Aircraft Departure Clearance Records</h1>
    @if(count($dposts) > 0)
        @foreach($dposts as $dpost)
            <div class="well">
                <div class="row">                   
                    <div class="col-md-4 col-sm-4">
                            {{-- Record No : {{$dpost->id}} --}}
                        <h3> {{-- {{$dpost->id}}.  --}} <a href="/dposts/{{$dpost->id}}">{{$dpost->flightno}}</a></h3>
                        <small>Entered on {{$dpost->created_at}} by {{$dpost->user->name}} (ATCT)</small>
                    </div>
                </div>
            </div>
        @endforeach
        {{$dposts->links()}}
    @else
        <p>No Aircraft Departure Clearance Records Found</p>
    @endif
@endsection