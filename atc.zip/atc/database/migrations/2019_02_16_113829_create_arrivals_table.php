<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArrivalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('arrivals', function (Blueprint $table) {
            $table->increments('id');
            //$table->integer('posts_id')->unsigned()->index()->default(2);
            //$table->string('flightno', 7); Security_Code
            $table->string('Security_Code')->nullable();
            $table->string('aflightno', 7);
            $table->string('cleaning')->nullable();
            $table->string('rampservice')->nullable();
            $table->string('waste')->nullable();
            $table->string('deicing')->nullable();
            
            $table->foreign('aflightno')
                    ->references('flightno')->on('posts')->onUpdate('cascade')
                    ->onDelete('cascade');
            $table->timestamps();
        });
        //Schema::enableForeignKeyConstraints();
        /*  Schema::table('arrivals', function (Blueprint $table) {
            $table->foreign('posts_id')->references('id')->on('posts')->onUpdate('cascade')->onDelete('cascade');
        }); */ 
        /* Schema::table('arrivals', function (Blueprint $table) {
            $table->foreign('posts_flightno')->references('flightno')->on('posts')->onDelete('cascade');
        }); */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('arrivals');
    }
}
