<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDeptsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('depts', function (Blueprint $table) {
            $table->increments('id');
            //$table->integer('posts_id')->unsigned()->index()->default(2);
            //$table->string('flightno', 7);
            $table->string('Security_Code')->nullable();
            $table->string('dflightno', 7);
            $table->string('cleaning')->nullable();
            $table->string('rampservice')->nullable();
            $table->string('waste')->nullable();
            $table->string('deicing')->nullable();
            
            $table->foreign('dflightno')
                    ->references('flightno')->on('dposts')->onUpdate('cascade')
                    ->onDelete('cascade');
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('depts');
    }
}
