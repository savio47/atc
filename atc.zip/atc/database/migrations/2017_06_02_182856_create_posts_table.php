<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('flightno', 7)->index();
            $table->string('flighttype');
            $table->string('toa');
            $table->string('doa');
            $table->string('runway');
            $table->string('route');
            $table->string('parking');
            // $table->foreign('flightno')->references('flightno')->on('posts')->onDelete('cascade');
            $table->timestamps();
        });
        //Schema::enableForeignKeyConstraints();
        /* foreach ($posts as $post){
            $arrival = new Arrival;
            $arrival->flightno = $post->flightno;
            $arrival->save();
        } */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
