<?php $__env->startSection('content'); ?>
<a href="/depts/" class="btn btn-default">Go Back</a>
    <h1>Before Departure Requests</h1>
    <?php echo Form::open(['action' => ['DeptsController@update', $dept->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        
        <h3 style="color:red;">Flight number: <?php echo e($dept->dflightno); ?> </h3>
        
        <div class="form-group">
            <?php echo e(Form::label('Security_Code', 'Security Code of Flight :')); ?>

            <?php echo e(Form::text('Security_Code', '', ['class' => 'form-control', 'placeholder' => 'Enter Secutity Code / OTP of flight'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('cleaning', 'Plane Outer inspection : ')); ?>

            <?php echo e(Form::select('cleaning', ['Yes' => 'Yes', 'No' => 'No'], $dept->cleaning,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('rampservice', 'Supplies and Inventory Check : ')); ?>

            <?php echo e(Form::select('rampservice', ['Yes' => 'Yes', 'No' => 'No'], $dept->rampservice,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('waste', 'Catering Service : ')); ?>

            <?php echo e(Form::select('waste', ['Yes' => 'Yes', 'No' => 'No'], $dept->waste,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('deicing', 'Deicing : ')); ?>

            <?php echo e(Form::select('deicing', ['Yes' => 'Yes', 'No' => 'No'], $dept->deicing,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div>  
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <br><br>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>