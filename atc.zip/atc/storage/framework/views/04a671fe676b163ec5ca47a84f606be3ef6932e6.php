<?php $__env->startSection('content'); ?>

<a href="/dposts/create" class="btn btn-primary btn-lg btn-block">Create Aircraft Departure Clearance Record</a>
    <br><br>
    <h1 style="color:purple;"> Aircraft Departure Clearance Records</h1>
    <?php if(count($dposts) > 0): ?>
        <?php $__currentLoopData = $dposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <div class="row">                   
                    <div class="col-md-4 col-sm-4">
                            
                        <h3>  <a href="/dposts/<?php echo e($dpost->id); ?>"><?php echo e($dpost->flightno); ?></a></h3>
                        <small>Entered on <?php echo e($dpost->created_at); ?> by <?php echo e($dpost->user->name); ?> (ATCT)</small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($dposts->links()); ?>

    <?php else: ?>
        <p>No Aircraft Departure Clearance Records Found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>