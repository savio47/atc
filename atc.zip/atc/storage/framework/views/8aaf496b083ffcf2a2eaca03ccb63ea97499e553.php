<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<body>

    <h1> Aircraft On Arrival Requests</h1>
    <br>   
    <?php if(count($arrivals) > 0): ?>        
            
            <table class="table table-striped table-bordered table-sm">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Cleaning </h3></th> 
                    <th><h3 style="color:purple;">Ramp Service</h3></th>
                    <th><h3>Waste Collection Truck</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                <?php $__currentLoopData = $arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($arrival->cleaning == null): ?>
                
                <tr>
                        
                            <td><h3 style="color:red;"><?php echo e($arrival->aflightno); ?> </h3></td> 
                            
                            <td colspan="4"><h3 style="color:green;"><a href="arrivals/<?php echo e($arrival->id); ?>/edit" class="btn btn-primary btn-lg btn-block">Create</a></h3></td>
                            
                                </div>
                              </div>
                            </div>  
                        </td>
    
                </tr>
                <?php endif; ?>
                <?php if($arrival->cleaning != null): ?>
                    <tr>
                        <td><h3 style="color:red;"><?php echo e($arrival->aflightno); ?> </h3></td>
                        <td><h3 style="color:green;"><?php echo $arrival->cleaning; ?></h3></td>
                        <td><h3 style="color:purple;"><?php echo $arrival->rampservice; ?></h3></td>
                        <td><h3><?php echo $arrival->waste; ?></h3></td>
                        <td><h3 style="color:blue;"><?php echo $arrival->deicing; ?></h3></td>
                        
                    </tr>
                    <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        
        
    <?php else: ?>
        <p>No Records Found</p>
    <?php endif; ?>
  </body>
  </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>