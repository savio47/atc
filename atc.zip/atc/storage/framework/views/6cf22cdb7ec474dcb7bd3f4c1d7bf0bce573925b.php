<?php $__env->startSection('content'); ?>
    <h1>Create Aircraft Departure Clearance Record</h1>
    <?php echo Form::open(['action' => 'DpostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    
        <div class="form-group">
            <?php echo e(Form::label('flightno', 'Flight No.')); ?>

            <?php echo e(Form::text('flightno', '', ['class' => 'form-control', 'placeholder' => 'Flight no (eg:KL722)'])); ?>

        </div>
        
        <div class="form-group">
            <?php echo e(Form::label('flighttype', 'Flight Type :')); ?>

            <?php echo e(Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], null,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('tod', 'Time of Departure : (Hours(24) : Minutes : Seconds)')); ?>

            <?php echo e(Form::time('tod', Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('H:i:s'),['class' => 'form-control', 'placeholder' =>'Departure Time'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('dod', 'Date of Departure : (Date - Month - Year)')); ?>

            <?php echo e(Form::date('dod', \Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('d-m-Y'),['class' => 'form-control', 'placeholder' =>'Departure Date'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('runway', 'Runway ( 12/30 ; L/R ) ')); ?>

            <?php echo e(Form::select('runway', ['12L' => '12L', '30R' => '30R', '12R' => '12R','30L' => '30L'], null,['class' => 'form-control', 'placeholder' =>'Select Runway and direction'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('route', 'Route ')); ?>

            <?php echo e(Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], null,['class' => 'form-control', 'placeholder' =>'Select the Route to travel'])); ?>

        </div>
        
        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        
    <?php echo Form::close(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>