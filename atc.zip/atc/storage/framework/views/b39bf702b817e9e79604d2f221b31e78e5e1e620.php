<?php $__env->startSection('content'); ?>
<body>
    <div class="jumbotron text-center">
        <img src="storage\_images\ATC_tower.jpg" class="img-fluid" alt="Responsive image" width="80%" height="240"> 
        <div class="container">
        <h1 style="color:blue;">Welcome To Ground Aircraft Handling and Support System</h1>
        
        
    </div>
    </div>
</body>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>