<?php $__env->startSection('content'); ?>

    <h1>Create Aircraft Arrival Clearance Record</h1>
    <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('flightno', 'Flight No.')); ?>

            <?php echo e(Form::text('flightno', '', ['class' => 'form-control', 'placeholder' => 'Flight no. format (eg:KL722)'])); ?>

        </div>      
        
        
        <div class="form-group">
            <?php echo e(Form::label('flighttype', 'Flight Type :')); ?>

            <?php echo e(Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], null,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('toa', 'Time of Arrival : (Hours(24) : Minutes : Seconds)')); ?>

            
            <?php echo e(Form::time('toa', Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('H:i:s'),['class' => 'form-control', 'placeholder' =>'Arrival Time'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('doa', 'Date of Arrival : (Date - Month - Year)')); ?>

            <?php echo e(Form::date('doa', \Carbon\Carbon::now()->timezone('Asia/Calcutta')->format('d-m-Y'),['class' => 'form-control', 'placeholder' =>'Arrival Date'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('runway', 'Runway ( 12 L/R ) ')); ?>

            <?php echo e(Form::select('runway', ['12R' => '12R','12L' => '12L'], null,['class' => 'form-control', 'placeholder' =>'Select Runway and direction'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('route', 'Route ')); ?>

            <?php echo e(Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], null,['class' => 'form-control', 'placeholder' =>'Select the Route to travel'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('parking', 'Parking Space: ')); ?>

            <?php echo e(Form::select('parking', ['P1' => 'P1', 'P2' => 'P2', 'P3' => 'P3','P4' => 'P4', 'P5' => 'P5'], null,['class' => 'form-control', 'placeholder' =>'Select the Parking Space'])); ?>

        </div> 
        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>