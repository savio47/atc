<?php $__env->startSection('content'); ?>
    <a href="/dposts" class="btn btn-default">Go Back</a>
    <br>
    <h1><?php echo e($dpost->flightno); ?></h1>
    <br>
    <div class="well">
        
        <h2>Flight No. : <?php echo $dpost->flightno; ?> </a></h2>
        <h4>Flight Type : <?php echo $dpost->flighttype; ?></h4>
        <h4>Time of Departure : <?php echo $dpost->tod; ?></h4> 
        <h4>Date of Departure : <?php echo $dpost->dod; ?></h4>   
        <h4>Runway : <?php echo $dpost->runway; ?></h4>
        <h4>Route : <?php echo $dpost->route; ?></h4>
        
    <br>
</div>
    <hr>
    <small>Entered on <?php echo e($dpost->created_at); ?> by <?php echo e($dpost->user->name); ?> (ATCT)</small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $dpost->user_id): ?>
           <a href="/dposts/<?php echo e($dpost->id); ?>/edit" class="btn btn-success">Edit</a> 

            <?php echo Form::open(['action' => ['PostsController@destroy', $dpost->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>