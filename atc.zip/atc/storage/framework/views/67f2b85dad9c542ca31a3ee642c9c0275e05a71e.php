<?php $__env->startSection('content'); ?>
<a href="/dposts/<?php echo e($dpost->id); ?>" class="btn btn-default">Go Back</a>
    <h1>Edit Aircraft Departure Clearance Record</h1>
    <?php echo Form::open(['action' => ['DpostsController@update', $dpost->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('flightno', 'Flight No.')); ?>

            <?php echo e(Form::text('flightno', $dpost->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no', /* 'disabled' */])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('flighttype', 'Flight Type :')); ?>

            <?php echo e(Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], $dpost->flighttype,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('tod', 'Time of Departure : (Hours : Minutes : Seconds)')); ?>

            <?php echo e(Form::time('tod', $dpost->tod,['class' => 'form-control'])); ?> 
        </div> 
        <div class="form-group">
            <?php echo e(Form::label('dod', 'Date of Departure : (Date - Month - Year)')); ?>

            <?php echo e(Form::date('dod', $dpost->dod,['class' => 'form-control'])); ?> 
        </div>
        <div class="form-group">
            <?php echo e(Form::label('runway', 'Runway :')); ?>

            <?php echo e(Form::select('runway', ['12L' => '12L', '12R' => '12R'], $dpost->runway,['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('route', 'Route ')); ?>

            <?php echo e(Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], $dpost->route,['class' => 'form-control'])); ?>

        </div>
        

        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <br><br>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>