<?php $__env->startSection('content'); ?>
    <h1>Create Aircraft On Arrival Requests</h1>
    <?php echo Form::open(['action' => 'ArrivalsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

       
     <div class="form-group">
        <?php echo e(Form::label('flightno', 'Flight No.')); ?>

        <?php echo e(Form::text('flightno', $post->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no'])); ?>

    </div>
         
        <div class="form-group">
            <?php echo e(Form::label('cleaning', 'Cleaning : ')); ?>

            <?php echo e(Form::select('cleaning', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('rampservice', 'Ramp Service : ')); ?>

            <?php echo e(Form::select('rampservice', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('waste', 'Waste Collection Truck : ')); ?>

            <?php echo e(Form::select('waste', ['Yes' => 'Yes', 'No' => 'No'], null,['class' => 'form-control', 'placeholder' =>'Select the option'])); ?>

        </div> 
        <div class="form-group">
            <?php echo e(Form::label('deicing', 'Deicing : ')); ?>

            <?php echo e(Form::select('deicing', ['Yes' => 'Yes', 'No' => 'No'], 'No',['class' => 'form-control'])); ?>

        </div>  


        

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>