<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<body>

    <h1> Aircraft Before Departure Requests</h1>
    <br>   
    <?php if(count($depts) > 0): ?>        
            
            <table class="table table-striped table-bordered table-sm">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Plane Outer inspection </h3></th> 
                    <th><h3 style="color:purple;">Supplies and Inventory Check</h3></th>
                    <th><h3>Catering Service</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($dept->cleaning == null): ?>
                
                <tr>
                        
                            <td><h3 style="color:red;"><?php echo e($dept->dflightno); ?> </h3></td> 
                            
                            <td colspan="4"><h3 style="color:green;"><a href="depts/<?php echo e($dept->id); ?>/edit" class="btn btn-primary btn-lg btn-block">Create</a></h3></td>
                            <td colspan="4">
                            </tr>
                           
                <?php endif; ?>
                <?php if($dept->cleaning != null): ?>
                    <tr>
                        <td><h3 style="color:red;"><?php echo e($dept->dflightno); ?> </h3></td>
                        <td><h3 style="color:green;"><?php echo $dept->cleaning; ?></h3></td>
                        <td><h3 style="color:purple;"><?php echo $dept->rampservice; ?></h3></td>
                        <td><h3><?php echo $dept->waste; ?></h3></td>
                        <td><h3 style="color:blue;"><?php echo $dept->deicing; ?></h3></td>
                        
                    </tr>
                    <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        
        
    <?php else: ?>
        <p>No Records Found</p>
    <?php endif; ?>
  </body>
  </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>