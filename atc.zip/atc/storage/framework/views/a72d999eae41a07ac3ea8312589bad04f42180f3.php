<?php $__env->startSection('content'); ?>
    <a href="/arrivals" class="btn btn-default">Go Back</a>
    <br>
    <h1><?php echo e($arrival->flightno_a); ?></h1>
    <br>
    <div class="well">
        
        <h2>Flight No. : <?php echo $arrival->flightno; ?> </a></h2>
        <h4>Cleaning : <?php echo $arrival->cleaning; ?></h4>
        <h4>Ramp Service : <?php echo $arrival->rampservice; ?></h4> 
        <h4>Waste Collection Truck : <?php echo $arrival->waste; ?></h4>   
        <h4>Deicing : <?php echo $arrival->deicing; ?></h4>
        <br>
</div>
    <hr>
    <small>Entered on <?php echo e($arrival->created_at); ?> by <?php echo e($arrival->user->name); ?> (ATCT)</small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $arrival->user_id): ?>
           <a href="/arrivals/<?php echo e($arrival->id); ?>/edit" class="btn btn-success">Edit</a> 

            <?php echo Form::open(['action' => ['ArrivalsController@destroy', $arrival->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>