<?php $__env->startSection('content'); ?>
    <h1><?php echo $title; ?></h1>
    <p>This is the about page</p>

    <br><br>
    <h1> Aircraft On Arrival Requests</h1>
    <br>
    <?php if(count($arrivals) > 0): ?>
            <table class="table table-striped">
                <tr>
                    <th><h3 style="color:red;">Flight number</h3></th>
                    <th><h3 style="color:green;">Cleaning </h3></th> 
                    <th><h3 style="color:purple;">Ramp Service</h3></th>
                    <th><h3>Waste Collection Truck</h3></th>
                    <th><h3 style="color:blue;">Deicing</h3></th>
                </tr>
                <?php $__currentLoopData = $arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrival): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><h3 style="color:red;"><?php echo e($arrival->post_flightno); ?></h3></td>
                        <td><h3 style="color:green;"><?php echo $arrival->cleaning; ?></h3></td>
                        <td><h3 style="color:purple;"><?php echo $arrival->rampservice; ?></h3></td>
                        <td><h3><?php echo $arrival->waste; ?></h3></td>
                        <td><h3 style="color:blue;"><?php echo $arrival->deicing; ?></h3></td>
                        <td></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        
        
    <?php else: ?>
        <p>No Records Found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>