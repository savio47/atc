<?php $__env->startSection('content'); ?>
    <a href="/posts" class="btn btn-default">Go Back</a>
    <br>
    <h1><?php echo e($post->flightno); ?></h1>
    <br>
    <div class="well">
        
        <h2>Flight No. : <?php echo $post->flightno; ?> </a></h2>
        <h4>Flight Type : <?php echo $post->flighttype; ?></h4>
        <h4>Time of Arrival : <?php echo $post->toa; ?></h4> 
        <h4>Date of Arrival : <?php echo $post->doa; ?></h4>   
        <h4>Runway : <?php echo $post->runway; ?></h4>
        <h4>Route : <?php echo $post->route; ?></h4>
        <h4>Parking Space: <?php echo $post->parking; ?></h4>
    <br>
</div>
    <hr>
    <small>Entered on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?> (ATCT)</small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
           <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-success">Edit</a> 

            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>