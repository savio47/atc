<?php $__env->startSection('content'); ?>
<a href="/posts/<?php echo e($post->id); ?>" class="btn btn-default">Go Back</a>
    <h1>Edit Aircraft Arrival Clearance Record</h1>
    <?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('flightno', 'Flight No.')); ?>

            <?php echo e(Form::text('flightno', $post->flightno, ['class' => 'form-control', 'placeholder' => 'Flight no', /* 'disabled' */])); ?>

        </div>
        
        <div class="form-group">
            <?php echo e(Form::label('flighttype', 'Flight Type :')); ?>

            <?php echo e(Form::select('flighttype', ['Small Aircraft' => 'Small Aircraft', 'Medium Range Aircraft' => 'Medium Range Aircraft','Large Aircraft' => 'Large Aircraft', 'Private Aircraft' => 'Private Aircraft','Helicopter' => 'Helicopter', 'Cargo' => 'Cargo'], $post->flighttype,['class' => 'form-control', 'placeholder' =>'Select Aircraft Type'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('toa', 'Time of Arrival : (Hours : Minutes : Seconds)')); ?>

            <?php echo e(Form::time('toa', $post->toa,['class' => 'form-control'])); ?> 
        </div> 
        <div class="form-group">
            <?php echo e(Form::label('doa', 'Date of Arrival : (Date - Month - Year)')); ?>

            <?php echo e(Form::date('doa', $post->doa,['class' => 'form-control'])); ?> 
        </div>
        <div class="form-group">
            <?php echo e(Form::label('runway', 'Runway :')); ?>

            <?php echo e(Form::select('runway', ['12L' => '12L', '30R' => '30R', '12R' => '12R','30L' => '30L'], $post->runway,['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('route', 'Route ')); ?>

            <?php echo e(Form::select('route', ['A' => 'A', 'B' => 'B', 'C' => 'C','D' => 'D'], $post->route,['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('parking', 'Parking Space: ')); ?>

            <?php echo e(Form::select('parking', ['P1' => 'P1', 'P2' => 'P2', 'P3' => 'P3','P4' => 'P4', 'P5' => 'P5'], $post->parking,['class' => 'form-control'])); ?>

        </div> 

        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <br><br>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>